angular.module('bustracker.controllers', ['backand', 'ngCordova', 'ngCookies'])

.controller('MapCtrl', function (Backand, $http, $scope, $cordovaGeolocation) {
	
	// Loads Google map, initializes with map elements and event listeners 
	initMap();
	
	function initMap() {
		loadDefaultMapView();
		loadControls();
	}
	
	function loadDefaultMapView(){
		var gtaLatLng = new google.maps.LatLng(43.5681, -79.7648); // Default location - Toronto GTA
		$scope.map = new google.maps.Map(document.getElementById("map"), {
		  center: gtaLatLng,
		  zoom: 10,
		  mapTypeId: google.maps.MapTypeId.ROADMAP,
		  disableDefaultUI: true
		});
		
		$scope.routeDrawn = false;
	}
	
	function loadControls(){
		var centerControlDiv = document.createElement('div');
		var centerControl = new CenterControl(centerControlDiv, $scope.map);
		centerControlDiv.index = -500;
		$scope.map.controls[google.maps.ControlPosition.TOP_LEFT].push(centerControlDiv);		
		
		//For stop tracker button
		var centerControlDivTwo = document.createElement('div');
		var centerControlTwo = new CenterControlTwo(centerControlDivTwo, $scope.map);
		centerControlDivTwo.index = 1;
		$scope.map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(centerControlDivTwo);
	}
			
    // Leverages Google Maps DirectionService and DistanceMatrixService APIs to display the "Driving" route and calculate the distance between two locations.	
	function trackBus(route, startLocation, currentDestinationRoute, destination){
		$scope.map.setCenter(startLocation);
		clearRoute();
			
		/*
		clearMap(); !!!!!!!!!!!!!!!!!!!!!
		$scope.directionsDisplay = new google.maps.DirectionsRenderer({
			map: $scope.map
		});
		
		// Set destination, origin and travel mode.
		var request = {
		  destination: currentDestinationRoute,
		  origin: startLocation,
		  travelMode: 'DRIVING'
		};
		
		// Pass the directions request to the directions service.
		var directionsService = new google.maps.DirectionsService();
		directionsService.route(request, function(response, status) {
		  if (status == 'OK') {
			// Display the route on the map.
			$scope.directionsDisplay.setDirections(response);
		  }
		});
		*/
		
		var service = new google.maps.DistanceMatrixService;			
		service.getDistanceMatrix({
		  origins: [startLocation],
		  destinations: [currentDestinationRoute],
		  travelMode: 'DRIVING',
		  unitSystem: google.maps.UnitSystem.METRIC,
		  avoidHighways: false,
		  avoidTolls: false
		}, function(response, status) {
		  if (status !== 'OK') {
			alert('Error was: ' + status);
		  } else {
				var distance = response.rows[0].elements[0].distance.text;
				var duration = response.rows[0].elements[0].duration.text;
			}
			loadMarker(startLocation, distance, duration, destination, route);
		});
	}
	
	function drawRoute(startLocation, currentDestinationRoute){
		//console.log("DrawingRoute..");
		$scope.directionsDisplay = new google.maps.DirectionsRenderer({
			map: $scope.map
		});
		
		// Set destination, origin and travel mode.
		var request = {
		  destination: currentDestinationRoute,
		  origin: startLocation,
		  travelMode: 'DRIVING'
		};
		
		// Pass the directions request to the directions service.
		var directionsService = new google.maps.DirectionsService();
		directionsService.route(request, function(response, status) {
		  if (status == 'OK') {
			// Display the route on the map.
			$scope.directionsDisplay.setDirections(response);
		  }
		});
		
		$scope.routeDrawn = true;
	}

// Displays marker at a given location and obtains the address of the marker
	function loadMarker(markerPosition, distance, duration, destination, route){

		var location = routeInfo = busArrivalTime = "";
		
		$scope.marker = new google.maps.Marker({
			map: $scope.map,
			//animation: google.maps.Animation.DROP,
			icon: 'img/shuttle.png',
			position: markerPosition
		});
		
		var geocoder = new google.maps.Geocoder;
		geocoder.geocode({'latLng': markerPosition}, function(results, status){
		  if(status == google.maps.GeocoderStatus.OK){
			location = results[0].formatted_address;
		  }else{
			location = "N/A";
		  }
	
		busArrivalTime = getEstimatedTime(duration);

		routeInfo =  '<div class="infoBoxHeaderLeft">' +
		'<h1 id="firstHeading" class="infoBoxHeaderLeft">' + route + " Shuttle" + '</h1>'+
		'<p>Destination: ' + destination
		+ '<p><span>Current Location: </span>' + location
		+ '<p><span>Duration: </span>' + duration 
		+ ' </p> <p><span>Distance: </span>' + distance + '</p> '
		+ ' </p> <p><span>Estimated Arrival: </span>' + busArrivalTime+ '</p> ' + '</div>';

		addInfoWindow($scope.marker, routeInfo);
	  });
	}
		
	// Displays information via Google Maps API InfoWindow
	function addInfoWindow(marker, locationContent) {			
		$scope.infoWindow = new google.maps.InfoWindow({
			content: locationContent
		});
		$scope.infoWindow.open($scope.map, $scope.marker);
	}
		
	// Clears display information from map interface
	function clearMap(){
		if($scope.infoWindow) $scope.infoWindow.close();
		if($scope.directionsDisplay) $scope.directionsDisplay.setMap(null);
		if($scope.marker) $scope.marker.setMap(null);
		$scope.routeDrawn = false;
		//console.log("ClearingMap..");
	}
	
	function clearRoute(){
	//	console.log("ClearingRoute..");
		if($scope.infoWindow) $scope.infoWindow.close();
		if($scope.marker) $scope.marker.setMap(null);
	}
	
	// Calculates and returns the total trip time based on the current time and trip duration
	function getEstimatedTime(duration){
		var d = new Date();
		var hour = d.getHours();
		var mins = d.getMinutes();
		var timeConvension = "";
		var durTime = durMins = tripTime = durHour = "";
		
		if (hour > 12){
			hour -= 12;
			timeConvension = "PM";
		}else{
			timeConvension = "AM";
		}
		
		var tripDur = duration.split(" ");
		var currTime = hour + ":" + mins;
	
		 // Distance is less than 1 hour
		if (tripDur.length == 2){
			durMins = tripDur[0];
			durTime = "00" + ":" + durMins;		
		}
		
		// Distance is greater than 1 hour
		if (tripDur.length == 4){ 
			durHour = tripDur[0];
			durMins = tripDur[2];
			durTime = durHour + ":" + durMins;
		}
		tripTime = addTimes(currTime, durTime, timeConvension);
		return tripTime;
	}

	// Returns the addition of two times and returns the total based on a 12 hour clock period
	function addTimes(start, end, timeConvension) {
		times = [];
		times1 = start.split(':');
		times2 = end.split(':');
		
		for (var i = 0; i < 2; i++) {
			times1[i] = (isNaN(parseInt(times1[i]))) ? 0 : parseInt(times1[i])
			times2[i] = (isNaN(parseInt(times2[i]))) ? 0 : parseInt(times2[i])
			times[i] = times1[i] + times2[i];
		}

		var minutes = times[1];
		var hours = times[0];
		
		if (minutes >= 60) {
			var res = (minutes / 60) | 0;
			hours += res;
			minutes = minutes - (60 * res);
		}
		
		if(minutes < 10){
			minutes = ('0' + minutes).slice(-2); 
		} 
	  
		if(hours >= 12){
			if (hours != 12) hours -= 12;
		
			if(timeConvension == "AM"){
			  timeConvension = "PM";
			}else{
			  timeConvension = "AM";
			}
		}		
		return hours + ':' + minutes + " " + timeConvension;
	}
		
	// Resets the tracking functionality
	function stopTracker(){
		if($scope.hamiltonInt) clearInterval($scope.hamiltonInt);
		if($scope.waterlooInt) clearInterval($scope.waterlooInt);
		if($scope.missInt) clearInterval($scope.missInt);
		if($scope.torontoInt) clearInterval($scope.torontoInt);
		if($scope.northYorkInt) clearInterval($scope.northYorkInt);
		if($scope.dtInt) clearInterval($scope.dtInt);
		if($scope.yorkUInt) clearInterval($scope.yorkUInt);
		if($scope.scarInt) clearInterval($scope.scarInt);
	}
	
	// Displays a drop-down menu on the map interface. Event listeners are also attached to each menu item
	function CenterControl(controlDiv, map) {	
		var mapPickupSpot = document.createElement('div');
		mapPickupSpot.className = "dropdown";
		controlDiv.append(mapPickupSpot);

		var box = document.createElement('BUTTON');
		box.innerHTML = 'SELECT SHUTTLE ROUTE';
		box.style.height = '50px';
		box.style.width = '250px';
		box.className = "dropbtn";
		mapPickupSpot.appendChild(box); 

		var hamilton = {lat: 43.25, lng: -79.87};
		var hamiltonUI = document.createElement('div');
		hamiltonUI.className = "dropdown-content";
		hamiltonUI.tabIndex = "1"; // To allow focus state to the element
		hamiltonUI.title = 'Click to recenter the map to Hamilton';
		box.appendChild(hamiltonUI);
		var hamiltonText = document.createElement('div');
		hamiltonText.className = "mapControlsText";
		hamiltonText.innerHTML = 'Hamilton';
		hamiltonUI.appendChild(hamiltonText);

		var waterloo = {lat: 43.46, lng: -80.52};
		var waterlooUI = document.createElement('div');
		waterlooUI.className = "dropdown-content";
		waterlooUI.tabIndex = "1"; // To allow focus state to the element
		waterlooUI.title = 'Click to recenter the map to Hamilton';
		box.appendChild(waterlooUI);
		var waterlooText = document.createElement('div');
		waterlooText.className = "mapControlsText";
		waterlooText.innerHTML = 'Waterloo';
		waterlooUI.appendChild(waterlooText);

		var mississauga = {lat: 43.58, lng: -79.64};
		var mississaugaUI = document.createElement('div');
		mississaugaUI.className = "dropdown-content";
		mississaugaUI.tabIndex = "1";
		mississaugaUI.title = 'Click to recenter the map to Mississauga';
		box.appendChild(mississaugaUI);
		var mississaugaText = document.createElement('div');
		mississaugaText.className = "mapControlsText";
		mississaugaText.innerHTML = 'Mississauga';
		mississaugaUI.appendChild(mississaugaText);

		var toronto = {lat: 43.63, lng: -79.53};
		var torontoUI = document.createElement('div');
		torontoUI.className = "dropdown-content";
		torontoUI.tabIndex = "1";
		torontoUI.title = 'Click to recenter the map to Mississauga';
		box.appendChild(torontoUI);
		var torontoText = document.createElement('div');
		torontoText.className = "mapControlsText";
		torontoText.innerHTML = 'Toronto';
		torontoUI.appendChild(torontoText);

		var northYork = {lat: 43.76, lng: -79.41};
		var northYorkUI = document.createElement('div');
		northYorkUI.className = "dropdown-content";
		northYorkUI.tabIndex = "1";
		northYorkUI.title = 'Click to recenter the map to YorkU';
		box.appendChild(northYorkUI);
		var northYorkText = document.createElement('div');
		northYorkText.className = "mapControlsText";
		northYorkText.innerHTML = 'North York';
		northYorkUI.appendChild(northYorkText);

		var downtownToronto = {lat: 43.65, lng: -79.38};
		var downtownTorontoUI = document.createElement('div');
		downtownTorontoUI.className = "dropdown-content";
		downtownTorontoUI.tabIndex = "1";
		downtownTorontoUI.title = 'Click to recenter the map to Toronto';
		box.appendChild(downtownTorontoUI);
		var downtownTorontoText = document.createElement('div');
		downtownTorontoText.className = "mapControlsText";
		downtownTorontoText.innerHTML = 'Downtown Toronto';
		downtownTorontoUI.appendChild(downtownTorontoText);

		var yorkUni = {lat: 43.77, lng: -79.50};
		var yorkUniUI = document.createElement('div');
		yorkUniUI.className = "dropdown-content";
		yorkUniUI.tabIndex = "1";
		yorkUniUI.title = 'Click to recenter the map to YorkU';
		box.appendChild(yorkUniUI);
		var yorkUniText = document.createElement('div');
		yorkUniText.className = "mapControlsText";
		yorkUniText.innerHTML = 'York University';
		yorkUniUI.appendChild(yorkUniText);

		var scarborough = {lat: 43.77, lng: -79.23};
		var scarboroughUI = document.createElement('div');
		scarboroughUI.className = "dropdown-content";
		scarboroughUI.tabIndex = "1";
		scarboroughUI.title = 'Click to recenter the map to YorkU';
		box.appendChild(scarboroughUI);
		var scarboroughText = document.createElement('div');
		scarboroughText.className = "mapControlsText";
		scarboroughText.innerHTML = 'Scarborough';
		scarboroughUI.appendChild(scarboroughText);

		//If location cannot be found then set map to default location and infowindow ("Cannot find information for this route")
		hamiltonUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Hamilton", hamilton);
			$scope.hamiltonInt = setInterval(function() {getBusLocation("Hamilton", hamilton);},10000);	
		});

		waterlooUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Waterloo", waterloo);
			$scope.waterlooInt = setInterval(function() {getBusLocation("Waterloo", waterloo);},10000);	
		});

		mississaugaUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Mississauga", mississauga);
			$scope.missInt = setInterval(function() {getBusLocation("Mississauga", mississauga);},10000);	
		});

		torontoUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Toronto", toronto);
			$scope.torontoInt = setInterval(function() {getBusLocation("Toronto", toronto);},10000);	
		});

		northYorkUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("North York", northYork);
			$scope.northYorkInt = setInterval(function() {getBusLocation("North York", northYork);},10000);	
		});

		downtownTorontoUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Downtown Toronto", downtownToronto);
			$scope.dtInt = setInterval(function() {getBusLocation("Downtown Toronto", downtownToronto);},10000);	
		});

		yorkUniUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("York University", yorkUni);
			$scope.yorkUInt = setInterval(function() {getBusLocation("York University", yorkUni);},10000);	
		});

		scarboroughUI.addEventListener('click', function() {
			clearMap();
			stopTracker();
			getBusLocation("Scarborough", scarborough);
			$scope.scarInt = setInterval(function() {getBusLocation("Scarborough", scarborough);},10000);	
		});
	}
	
	function CenterControlTwo(controlDiv, map) {	
		var mapPickupSpot = document.createElement('div');
		mapPickupSpot.className = "dropdown";
		controlDiv.append(mapPickupSpot);
		
		var box = document.createElement('BUTTON');
		box.innerHTML = 'RESET TRACKER';
		box.style.height = '50px';
		box.style.width = '250px';
		box.className = "dropbtnStop ";
		mapPickupSpot.appendChild(box);
		
		box.addEventListener('click', function() {
			clearMap();
			stopTracker();
			initMap();
		});
	}
	
	// Track Bus
	function getBusLocation(route, defaultLoc){
		return backand.query.post("locationDownload", {
			"route": route
			}).then(function(result){	
				var nextStop = result.data[0].nextStop;
				
				if(nextStop == "null"){
					if($scope.directionsDisplay) $scope.directionsDisplay.setMap(null);
					locationUnavailable(defaultLoc, route);			
				}
				
				else{ // Bus Tracking Information Available
					var latitude = parseFloat(result.data[0].latitude);
					var longitude = parseFloat(result.data[0].longitude);
					var currentLocation = new google.maps.LatLng(latitude, longitude);
					var destination = result.data[0].nextStop;
					
					return backand.query.post("getDestinationDetails", {
					  "destination": destination
					}).then(function(result){
						var destLat = parseFloat(result.data[0].latitude);
						var destLng = parseFloat(result.data[0].longitude);
						var currentDestination = new google.maps.LatLng(destLat, destLng);
					//	if($scope.routeDrawn != true) drawRoute(currentLocation, currentDestination);
						trackBus(route, currentLocation, currentDestination, destination);
					});
				}
			});
	}
	
	function locationUnavailable(defaultLoc, route){
		clearRoute();
		$scope.map.setCenter(defaultLoc);
		$scope.map.setZoom(12);
		
		var position = new google.maps.LatLng(defaultLoc);
		$scope.marker = new google.maps.Marker({
			map: $scope.map,
			icon: 'img/shuttle.png',
			position: position
		});
		addInfoWindow($scope.marker, "<p><strong>Tracking information for " + route + " cannot be found. Retrying..</strong></p>");	
	}
});
