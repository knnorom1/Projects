var app = angular.module('bustracker', ['backand', 'ngCordova', 'ngCookies', 'bustracker.controllers'])
	
	app.config(function(BackandProvider, $httpProvider) {
	
      BackandProvider.setAppName('bustracker');
      BackandProvider.setSignUpToken('367f5f75-a324-49a3-b6cb-1d1e86703fdd');
      BackandProvider.setAnonymousToken('46d43a07-c173-4dd2-b40e-cce3a3cbbff8');
	  
	  var config = {
		appName: 'bustracker',
		anonymousToken: '46d43a07-c173-4dd2-b40e-cce3a3cbbff8',
		useAnonymousTokenByDefault: true
	 };
		 
	  backand.init(config);
	  
	  backand.object.getList('users')
	  .then((response) => {
	  })
	  .catch(function(error){
		  console.log(error);
	  });
	})

				